#include "poly.h"
#include<stdlib.h>
#include<string>
using namespace std;

polynomial::polynomial(){
}
string polynomial::display() {
    string s;   //dummy variable to return
    int sumx=0, sumy=0;
    int newMax = maxDegree;
    for (int i = maxDegree; i >= 0; i--) { //using i-- to check descending maxDegree, start with highest
        
        
        if (coeff[i] == 0) {
            sumx = sumx + coeff[i];
            if (i == 0 && sumx == 0) {
                cout << sumx;
            }
            newMax--;
            continue;   //goes to next degree of the polynomial if the coefficient is 0
        }else if (i == newMax || coeff[i] < 0) {
            if(i>1){
                cout << coeff[i] << "x^" << i;
            }else if(i==1){
                cout << coeff[i] << "x";
            }else{
                cout << coeff[i];
            }
        }else {
            if(i>1){
                cout << "+" << coeff[i] << "x^" << i;
            }else if(i==1){
                cout << "+" << coeff[i] << "x";
            }else{
                cout << "+" << coeff[i];
            }
        }
    }
    return s;
}
int polynomial::degree(){
    return maxDegree;
}

int polynomial::coefficient(int power){
    return coeff[power];
}
polynomial polynomial:: changeCoefficient(int newCoefficient, int power){
    polynomial changed;
    changed.maxDegree=maxDegree;
    for(int i=0;i<=maxDegree;i++){
        changed.coeff[i]=coeff[i];
    }
        changed.coeff[power]=newCoefficient;
    changed.display();
    return changed;
}

//function to recieve input data from user
int polynomial::get_data() {
    cin >> maxDegree;
    //coeff[] = new int[maxDegree + 1];
    for (int i = maxDegree; i >= 0; i--) {
        cout << "Enter coefficient of x^" << i << ":";
        cin >> coeff[i];
    }
    return 0;
}

//function to add polynomials using data inputed/recived from the user
polynomial polynomial::addition(polynomial P2) {
    //cout<<"add";
    polynomial sum;
    int max=0;
    if (maxDegree > P2.maxDegree) { // if if maxDegrees don't agree follow polynomial order of operations in calculations
        max=maxDegree;
    }else{
        max=P2.maxDegree;
    }
    sum.maxDegree=max;
    for(int i=0;i<=max;i++){
        sum.coeff[i]=coeff[i]+P2.coeff[i];
    }
    sum.display();
    return sum;
}

//function to subtract using data from user
polynomial polynomial::operator-() const{
    polynomial neg;
    neg.maxDegree=maxDegree;
    for(int i=0;i<=maxDegree;i++){
        neg.coeff[i]=-coeff[i];
    }
    neg.display();
    return neg;
}

//function to multiply given data from user
polynomial polynomial::operator*(int scalar) const{
    polynomial mul;
    mul.maxDegree=maxDegree;
    for(int i=0;i<=maxDegree;i++){
        mul.coeff[i]=coeff[i] *scalar;
    }
    mul.display();
    return mul;
}

//function to divide given information from user
polynomial polynomial::operator/(int dScale) const{
    polynomial div;
    div.maxDegree=maxDegree;
    for(int i=0;i<=maxDegree;i++){
        div.coeff[i]=coeff[i] /dScale;
    }
    div.display();
    return div;
}

ostream& operator<<(std::ostream& out, polynomial obj){
        out <<obj.display();
    return out;
}
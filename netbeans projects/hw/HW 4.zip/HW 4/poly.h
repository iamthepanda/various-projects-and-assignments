#ifndef POLY_H
#define POLY_H
#include<iostream>
#include<string>

class polynomial {
private:
    int maxDegree;
    double coeff[100];
public:
    friend std::ostream& operator<<(std::ostream& out, polynomial obj);
    polynomial();
    
    //variables to store degree and coefficients
    //int *coeff, maxDegree;
    //function protoypes of functions to be used
    
    int get_data();
    int degree();
    
    int coefficient(int power);
    polynomial changeCoefficient(int newCoefficient, int power);
    std::string display();
    
    polynomial addition(polynomial P2);
    polynomial operator*(int scalar) const;
    polynomial operator/(int scalar) const;
    polynomial operator-() const;
};

#endif
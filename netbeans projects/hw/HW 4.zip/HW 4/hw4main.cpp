//#include <iostream>
#include <stdlib.h>
#include "poly.h"
using namespace std;

int main() {
    int choice, scalar, power, newCoeff;
    //Abstract Data Type varibales for 3 polynomials
    //First two for input and last one for output
    polynomial P1, P2, P3;
    //cout << "Instruction: \nExample:\nP(x)=5x^3+3x^1\nEnter the Polynomial like\nP(x)=5x^3+0x^2+3x^1+0x^0\n" ;
    cout << "Enter Polynomial 1: " << endl;
    cout << "Enter Degree Of Polynomial: ";
    P1.get_data(); //accessing get_data(); function specifically for P1
    cout << "\n";
    cout << "Enter Polynomial 2: " << endl << "Enter Degree Of Polynomial: ";
    P2.get_data();
    cout << "\n";
    
    //Prompts user for choice of calculation using switch( better version of multiple if's and else if's
    while (1) {
        cout << "\nNumber corresponds to function" << endl;
        cout << "1: Addition\n2: Negation\n3: Multiplication\n4: Division"
                "\n5: Output\n6: Degree\n7: Show Coefficient"
                "\n8: Coefficient Changer\n0: Exit" << endl;
        cout << "Enter your choice: ";
        
        cin >> choice;
        switch (choice) {
            case 1:
                cout << "\n------------ Addition ----------\nPolynomial1: ";
                P1.display();
                cout << "\nPolynomial2: ";
                P2.display();
                cout << "\n\nAdded:";
                P3 = P1.addition(P2);
                cout << "\n--------------------------------\n";
                break;
                
            case 2:
                cout << "\n----------- Negation -----------\nPolynomial: ";
                P1.display();
                cout << "\n\nNegated:";
                P3=-P1;
                cout << "\n--------------------------------\n";
                break;
                
            case 3:
                cout << "\n-------- Multiplication --------\nPolynomial: ";
                P1.display();
                cout << "\nEnter a scalar:";
                cin >> scalar;
                cout << "\n\nMultiplied:";
                P3=P1 *scalar;
                cout << "\n--------------------------------\n";
                break;
                
            case 4:
                cout << "\n----------- Division -----------\nPolynomial: ";
                P1.display();
                cout << "\nEnter a scalar:";
                cin >> scalar;
                cout << "\n\nDivided:";
                P3=P1 /scalar;
                cout << "\n--------------------------------\n";
                break;
                
            case 5:
                cout << "\n----------- Output -------------\nPolynomial: ";
                P1.display();
                cout << "\n\nOutput:";
                cout <<P1;
                cout << "\n--------------------------------\n";
                break;
                
            case 6:
                cout << "\n----------- Degree -------------\nPolynomial: ";
                P1.display();
                cout << "\n\nDegree:";
                cout <<P1.degree();
                cout << "\n--------------------------------\n";
                break;
                
            case 7:
                cout << "\n------ Show Coefficient --------\nPolynomial: ";
                P1.display();
                cout << "\nEnter a degree: ";
                cin >> power;
                cout << "\nCoefficient: ";
                cout <<P1.coefficient(power);
                cout << "\n--------------------------------\n";
                break;
                
            case 8:
                cout << "\n----- Coefficient Changer ------\nPolynomial: ";
                P1.display();
                cout << "\nEnter a degree no larger than degree of first polynomial entered: ";
                cin >> power;
                cout << "Enter a new coefficient: ";
                cin >> newCoeff;
                cout << "\nChanged Coefficient: ";
                P3=P1.changeCoefficient(newCoeff, power);
                cout << "\n--------------------------------\n";
                break;
                
            case 0: //If user selects 0, program ends.
                cout << "Program Terminated by user" << endl;
                exit(0);
            default:
                break;
        }
    }
    return 0;
}
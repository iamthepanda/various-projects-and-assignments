/* 
 * File:        rectangle.cpp
 * Author:      George Jone
 * ID:          913177426
 * email:       jone@mail.sfsu.edu
 * Compiler:    GNU Cygwin g++
 * 
 * Created on May 15, 2015
 */

#include "rectangle.h"

void Rectangle::draw() {
    std::cout << "2drawing rectangle \n";
}

void Rectangle::erase() {
    std::cout << "2erasing rectangle \n";
}



